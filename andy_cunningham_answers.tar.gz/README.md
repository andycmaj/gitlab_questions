answers to questions: questions.md

ruby script: `healthcheck.rb {duration}`

```bash
./healthcheck.rb 5m
pinging https://gitlab.com until 12:39:39 local time (5m)
host replied in 0.097658
host replied in 0.073202
host replied in 0.059228
...
host replied in 0.060976
host replied in 0.063646
Average round-trip is 0.07065742063492061
p99 duration is 0.09063699999999998
0 pings failed
```